function output=qiuhe(input)
output=0;
for i=1:length(input)
    output=output+input(i);
end